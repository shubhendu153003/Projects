package com.wallet.bean;

import java.util.HashMap;

public class Account {

	private String account_type;
	private double account_balance;
	
	
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public double getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(double account_balance) {
		this.account_balance = account_balance;
	}
	
	
	
	public Account(String account_type, double account_balance) {
		super();
		this.account_type = account_type;
		this.account_balance = account_balance;
	}

	public Account() {
		super();
	}
	
}
