package com.wallet.dao;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.wallet.bean.Account;
import com.wallet.bean.AccountNumber;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.bean.TransactionNumber;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {

	static HashMap<String,Customer> accCustomerMap = Account.getAccCustMap();
	static HashMap<String,Account> accDetailsMap = Account.getAccDetailMap();
	static HashMap<String,Transaction> transactionMap = Transaction.getTransactionMap();
	
	@Override
	public String createAccount(Customer c, Account a) throws WalletException {
	
	AccountNumber acc = new AccountNumber();
	
	accCustomerMap.put(acc.getAccount_Number(), c);
	accDetailsMap.put(acc.getAccount_Number(), a);
		
	  return acc.getAccount_Number();
	}

	@Override
	public String showBalance(String accNumber) throws WalletException {
		String c = accDetailsMap.get(accNumber).getAccount_balance();
		if(c != null) {
			return c;
		}
		return null;
	}

	@Override
	public String deposit(String acc, String amt) throws WalletException {
		Account acct = accDetailsMap.get(acc);
		if(acct!= null) {
			String bal = acct.getAccount_balance();
			String updatedBal = Double.toString(Double.parseDouble(bal)+Double.parseDouble(amt));
			
			accDetailsMap.put(acc, new Account(acct.getAccount_type(),updatedBal));
			return updatedBal;
		}
		return null;
	}

	@Override
	public String withdraw(String acc, String amt) throws WalletException {
		
		Account acct = accDetailsMap.get(acc);
		
			String bal = acct.getAccount_balance();
			String updatedBal = Double.toString(Double.parseDouble(bal)-Double.parseDouble(amt));
			
			accDetailsMap.put(acc, new Account(acct.getAccount_type(),updatedBal));
			return updatedBal;
		
	}

	@Override
	public boolean checkAccountExist(String acc) throws WalletException {
		Account acct = accDetailsMap.get(acc);
		if(acct!=null) {
			return true;
		}
		return false;
	}

	@Override
	public String fundTransfer(String acc, String amt, String rAcc) throws WalletException {
		
		Account sender = accDetailsMap.get(acc);
		Account receiver = accDetailsMap.get(rAcc);
		
		String senderAmtUpdate = Double.toString(Double.parseDouble(sender.getAccount_balance()) - Double.parseDouble(amt) );
		String receiverAmtUpdate = Double.toString(Double.parseDouble(receiver.getAccount_balance()) + Double.parseDouble(amt));
		
		accDetailsMap.put(acc, new Account(sender.getAccount_type(), senderAmtUpdate));
		accDetailsMap.put(rAcc, new Account(receiver.getAccount_type(), receiverAmtUpdate));
		
		return senderAmtUpdate;
	}

	@Override
	public String dwTransaction(String status, String transaction_type, String account, LocalDate date, String amount) throws WalletException {
		TransactionNumber tNumber = new TransactionNumber();
	 
		  transactionMap.put(tNumber.getTransaction_Number(), new Transaction(status,transaction_type,account,date,amount));
		
	 return tNumber.getTransaction_Number();	
	}

	@Override
	public String transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc,LocalDate date, String amount) throws WalletException {
		TransactionNumber tNumber = new TransactionNumber();
		 
		  transactionMap.put(tNumber.getTransaction_Number(), new Transaction(status, transaction_type, senderAcc, receiverAcc, date, amount));
		
	 return tNumber.getTransaction_Number();	
	
	}

	@Override
	public HashMap<String, Transaction> printTransaction(String acc) throws WalletException {
		
		HashMap<String,Transaction> tMap = new HashMap<String,Transaction>();
		
		for(Map.Entry<String, Transaction> T: transactionMap.entrySet()){
			if(T.getValue().getSenderAcc().toString().equals(acc) || T.getValue().getReceiverAcc().toString().equals(acc) || T.getValue().getAccount().toString().equals(acc))
			 {
				tMap.put(T.getKey(), T.getValue());
			 }
		}
	 return tMap;
	}

	
	

}
