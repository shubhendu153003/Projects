package com.wallet.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	WalletDao wd = new WalletDaoImpl();
	
	Account a = new Account();
	/*@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}*/

	@Test
	public void testCreateAccount() {
       String id=null;
       //assertEquals(10, a.getAccDetailMap().size());
		try {
			id = wd.createAccount(new Customer("Somya","Barodra","28","8890925142"), new Account("savings",10000));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		assertNotNull(id);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testShowBalance() {
		try {
			assertEquals(10000,wd.showBalance("1003"),0.00);
		} catch (WalletException e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			double bal = wd.deposit("1001", 5000);
			assertEquals(5000,bal,0.0);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testWithdraw() {
		try {
			double bal = wd.withdraw("1001", 5000);
			assertEquals(5000,bal,0.0);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
/*    @Ignore
	@Test
	public void testCheckAccountExist() {
		fail("Not yet implemented");
	}

	*/@Test
	public void testFundTransfer() {
		try {
			double bal = wd.fundTransfer("1002", 1000,"1001");
			assertEquals(1000,bal,0.0);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}/*
    @Ignore
	@Test
	public void testDwTransaction() {
		fail("Not yet implemented");
	}
    @Ignore
	@Test
	public void testTransferTransaction() {
		fail("Not yet implemented");
	}
*/
	@Test
	public void testPrintTransaction() throws SQLException {
		try {
			assertTrue(wd.printTransaction("1001").next());
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			}	}

}
