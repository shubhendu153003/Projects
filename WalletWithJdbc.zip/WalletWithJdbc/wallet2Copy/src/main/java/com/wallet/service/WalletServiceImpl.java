package com.wallet.service;

import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {

	WalletDao wd = new WalletDaoImpl();
	
	@Override
	public String createAccount(Customer c, Account a) throws WalletException {
		return wd.createAccount(c,a);
	}

	@Override
	public boolean validateData(Customer c, Account a) throws WalletException {
		if(validateName(c.getName()) && validateAge(c.getAge()) && validatePhone(c.getPhone())/* && validateAccType(a.getAccount_type()) && validateInitBalance(a.getAccount_balance())*/) {
			
			
				if(a.getAccount_balance()<=0)
					throw new WalletException("Deposited Money should be greater than 0");
			
			return true;
		}
			return false;
	}
	
	private boolean validateName(String name) throws WalletException{
		if(name.isEmpty() || name==null) {
			throw new WalletException("Name cannot be empty.");
		}
		else {
			if(!name.matches("[A-Z][a-z]{3,}")) {
				throw new WalletException("Name should start with capital letter and contain minimum 3 characters.");
			}
		}
	 return true;
	}
	
	private boolean validateAge(String age) throws WalletException{
		if(age.isEmpty() || age==null) {
			throw new WalletException("Please enter age.");
		}
		else {
			int a;
			try {
				a = Integer.parseInt(age);
				
				if(a<=0) {
					throw new WalletException("Age cannot be less than 0"); 
				}
				else {
					return true;
				}
			} catch (Exception e) {
			    throw new WalletException("Age should be numerical.");	
			}
		}
	  
	}
	
	
	
	private boolean validatePhone(String phone) throws WalletException{
		
		if(phone.isEmpty() || phone==null) {
			throw new WalletException("Please enter phone number.");
		}
		else {
			 if(!phone.matches("\\d{10}")) {
				 throw new WalletException("Phone number should be 10 digits.");
			 }
		}
	return true;	
	}

	private boolean validateAccType(String type) throws WalletException{
		if(type.isEmpty() || type==null) {
			throw new WalletException("Account type cannot be empty.");
		}
		else {
			if(type.equalsIgnoreCase("savings")!=true && type.equalsIgnoreCase("current")!=true) {
				throw new WalletException("Account type can be only Savings or Current.");
			}
		}
	 return true;
	}
	

	@Override
	public double showBalance(String acc) throws WalletException {
		
		return wd.showBalance(acc);
	}

	@Override
	public double deposit(String acc, double amt) throws WalletException {
		try {
		//double d = Double.parseDouble(amt);
		if(amt<=0) {
			throw new WalletException("Amount should be greater than 0");
		}
		}catch (Exception e) {
			throw new WalletException("Enter valid amount.");
		}
		return wd.deposit(acc, amt);
	}

	
	
	

	@Override
	public double withdraw(String acc, double amt) throws WalletException {
		try {
		
		if(amt<=0) {
			throw new WalletException("Amount should be greater than 0");
		}
		}catch (Exception e) {
			throw new WalletException("Enter valid amount.");
		}
		return wd.withdraw(acc, amt);
	}

	
	
	

	@Override
	public double fundTransfer(String acc, double amt, String rAcc) throws WalletException {
		
		try {
			if(acc.equals(rAcc)) {
				throw new WalletException("Invalid transaction! Both account numbers same.");
			}
		
			if(amt<0) {
				throw new WalletException("Amount cannot be less than 0");
			}
			if(amt > (wd.showBalance(acc))) {
				throw new WalletException("Insufficient balance in the account to complete this transaction.");
			}
			else {
				return wd.fundTransfer(acc, amt, rAcc);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}catch (Exception e) {
			throw new WalletException("Enter only numerical");
		}
	 
	}

	@Override
	public double dwTransaction(String status, String transaction_type, String account, double amount) throws WalletException {
		return wd.dwTransaction(status, transaction_type, account, amount);
	}

	@Override
	public double transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc, double amount) throws WalletException {
		return wd.transferTransaction(status, transaction_type, senderAcc, receiverAcc ,amount);
	}

	@Override
	public ResultSet printTransaction(String acc) throws WalletException {
	
		return wd.printTransaction(acc);
	}

	@Override
	public boolean checkAccountExist(String acc) throws WalletException {
		// TODO Auto-generated method stub
		return wd.checkAccountExist(acc);
	}

	
}
