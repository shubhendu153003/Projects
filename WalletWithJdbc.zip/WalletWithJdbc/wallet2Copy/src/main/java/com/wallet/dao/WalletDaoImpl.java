package com.wallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wallet.util.DBConnection;
import com.wallet.dao.QueryMapper;
import com.wallet.exception.WalletException;
import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	
	
Logger logger=Logger.getRootLogger();
	
	
	public WalletDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	@SuppressWarnings("resource")
    @Override
	public String createAccount(Customer c, Account a) throws WalletException {
	
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		int queryResult=0;
		String accNo=null;
		
		
		
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,c.getName());
			preparedStatement.setString(2,c.getAddress());
			preparedStatement.setString(3,c.getAge());
			preparedStatement.setString(4,c.getPhone());
			
					
			 queryResult = preparedStatement.executeUpdate();
		
			preparedStatement1=connection.prepareStatement(QueryMapper.INSERT_QUERY1);
			
			preparedStatement1.setString(1,a.getAccount_type());
			preparedStatement1.setDouble(2,a.getAccount_balance());
			
			 queryResult = preparedStatement1.executeUpdate();
			
			preparedStatement1 = connection.prepareStatement(QueryMapper.EMPLOYEEID_QUERY_SEQUENCE);
			resultSet = preparedStatement1.executeQuery();
			resultSet.next();
			accNo=resultSet.getString(1);
						
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return accNo;
			}
		 }
		catch(SQLException sqlException)
		 {
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		 }
		finally
		 {
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		 }
		
	}

	@Override
	public double showBalance(String accNumber) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		
		
		ResultSet queryResult=null;
		double balance=0.0;
		
		
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY2);

			preparedStatement.setString(1,accNumber);
			
			 queryResult = preparedStatement.executeQuery();
			 queryResult.next();
			 balance=queryResult.getDouble(3);
			 
			if(queryResult==null)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return balance;
			}
		 }
		catch(WalletException e) 
		{
			//logger.error(sqlException.getMessage());
			throw new WalletException(e.getMessage());
		}
		catch(SQLException e) 
		{
			logger.error(e.getMessage());
			throw new WalletException("Sql Exception");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}
		
		
		
		
		
	}

	@Override
	public double deposit(String acc, double amt) throws WalletException {
		
	
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		
		//PreparedStatement preparedStatement1=null;
		ResultSet queryResult=null;
		ResultSet queryResult2=null;

		//int balance=0;
		int queryResult1=0;
		double balance1=0.0;
		//double amt1=Double.parseDouble(amt);
		
		try
		{		
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_QUERY_DEPOSIT);
         
			preparedStatement.setDouble(1,amt);
			preparedStatement.setString(2,acc);
			
			
			 queryResult1 = preparedStatement.executeUpdate();
			 
			if(queryResult1==0)
			{
				throw new WalletException("Record Not Inserted");
			}
			
			 return amt;
			 
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		catch(WalletException e)
		{
			logger.error(e.getMessage());
			//e.printStackTrace();
			throw new WalletException(e.getMessage());
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}
	
	}

	
	
	

	@Override
	public double withdraw(String acc, double amt) throws WalletException {
		
	
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		
		ResultSet queryResult=null;
		ResultSet queryResult2=null;

		int queryResult1=0;
		double balance1=0.0;
	
		try
		{		
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_QUERY_WITHDRAW);
          
			preparedStatement.setDouble(1,amt);
			preparedStatement.setString(2,acc);
			
			
			 queryResult1 = preparedStatement.executeUpdate();
			 if(queryResult1==0)
				{
					throw new WalletException("Record Not Inserted");
				}
	
			 return amt;
			 
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}
	
	}	

    @Override
	public boolean checkAccountExist(String acc) throws WalletException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;	
		ResultSet queryResult=null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY2);
	          
			preparedStatement.setString(1,acc);
			 queryResult = preparedStatement.executeQuery();
			 if(!queryResult.next())
			 {
				 throw new WalletException("AccountNumber "+ acc +" Not Exist");
			 }
			return true;
		}
		catch(WalletException e)
		{
			throw new WalletException(e.getMessage());
		}
		catch(SQLException e)
		{
			throw new WalletException("Problem in Sql");
		}
	}

	@Override
	public double fundTransfer(String acc, double amt, String rAcc) throws WalletException {
		
		Connection connection = DBConnection.getInstance().getConnection();	

        PreparedStatement preparedStatement=null;
        PreparedStatement preparedStatement1=null;
		
		int queryResult=0;
		int queryResult1=0;
		double balance1=0.0;
	
		try
		{		
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_QUERY_FUND_TRANFER_FROM);
          
			preparedStatement.setDouble(1,amt);
			preparedStatement.setString(2,acc);
			
			
			 queryResult = preparedStatement.executeUpdate();
			 
			 
			 preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_QUERY_FUND_TRANSFER_TO);
	          
			 preparedStatement1.setDouble(1,amt);
			 preparedStatement1.setString(2,rAcc);
				
				
			 queryResult= preparedStatement1.executeUpdate(); 
			 
			 
	
	
			 return amt;
			 
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}
	}


	public double dwTransaction(String status, String transaction_type, String account, 
			double amount) throws WalletException {
			
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		int queryResult=0;
		int queryResult1=0;
		double balance1=0.0;
        
		try
		{		
			
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY_TRANSACTION);
         
			preparedStatement.setString(1,transaction_type);
			preparedStatement.setString(2,account);
			//preparedStatement.setDate(3,(Date) date);
			preparedStatement.setDouble(3, amount);
			preparedStatement.setString(4,null);
			preparedStatement.setString(5,null);
			
			
			
			 queryResult = preparedStatement.executeUpdate();
	
			 return 1;
			 
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}
	}





	
	
	public double transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc, double amount) throws WalletException  {
			
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		int queryResult=0;
		int queryResult1=0;
		double balance1=0.0;
        
		try
		{		
			
			
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY_TRANSACTION);
         
			preparedStatement.setString(1,transaction_type);
			preparedStatement.setString(2,null);
			preparedStatement.setDouble(3, amount);
			preparedStatement.setString(4,senderAcc);
			preparedStatement.setString(5,receiverAcc);
			
			
			
			 queryResult = preparedStatement.executeUpdate();
			 return 1;
			 
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		
		}

	}


	@Override
	public ResultSet printTransaction(String acc) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;	
		ResultSet queryResult=null;
		ResultSet queryResult1=null;
		
		
		  
				try
				{		
					
					
					
					preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
		         
					preparedStatement.setString(1,acc);
					preparedStatement.setString(2,acc);
					preparedStatement.setString(3, acc);
			
					queryResult = preparedStatement.executeQuery();
		            return queryResult;
					 
				 }
				catch(SQLException sqlException)
				{
					logger.error(sqlException.getMessage());
					sqlException.printStackTrace();
					throw new WalletException("Tehnical problem occured refer log");
				}
				finally
				{
					try 
					{
						
					}
					catch (Exception sqlException) 
					{
						logger.error(sqlException.getMessage());
						throw new WalletException("Error in closing db connection");	
					}
				
				}
	}
}
