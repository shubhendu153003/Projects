package com.wallet.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	WalletDao wd = new WalletDaoImpl();
	
	Account a = new Account();
	/*@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}*/

	@Test
	public void testCreateAccount() {

		assertEquals(10, a.getAccDetailMap().size());
		try {
			String id = wd.createAccount(new Customer("Mohan","Vallacheri","34","9956725142"), new Account("savings","25000"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		assertEquals(11, a.getAccDetailMap().size());
	}

	@Test
	public void testShowBalance() {
		try {
			assertEquals("45000",wd.showBalance("SCB1531121607192"));
		} catch (WalletException e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			String bal = new String(wd.deposit("SCB1531121607192", "5000"));
			assertEquals("50000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testWithdraw() {
		try {
			String bal = new String(wd.withdraw("SCB1531121607189", "50000"));
			assertEquals("800000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
    @Ignore
	@Test
	public void testCheckAccountExist() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		try {
			String bal = new String(wd.fundTransfer("SCB1531121607195", "1000","SCB1531121607180"));
			assertEquals("96000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
    @Ignore
	@Test
	public void testDwTransaction() {
		fail("Not yet implemented");
	}
    @Ignore
	@Test
	public void testTransferTransaction() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(0,wd.printTransaction("SCB1531121607173").size());
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			}	}

}
