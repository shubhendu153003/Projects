package com.wallet.service;

import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface WalletService {

	public String createAccount(Customer c, Account a) throws WalletException;
	public boolean validateData(Customer c, Account a) throws WalletException;
	public double showBalance(String acc) throws WalletException;
	public double deposit(String acc, double amt) throws WalletException;
	public double withdraw(String acc,double amt) throws WalletException;
	public double fundTransfer(String acc, double amt, String rAcc) throws WalletException;
	public boolean checkAccountExist(String acc) throws WalletException;
	
	public double dwTransaction(String status, String transaction_type, String account, double amount) throws WalletException;
	public double transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc, double amount) throws WalletException;
	
	
	
	public ResultSet printTransaction(String acc) throws WalletException;

	
}
