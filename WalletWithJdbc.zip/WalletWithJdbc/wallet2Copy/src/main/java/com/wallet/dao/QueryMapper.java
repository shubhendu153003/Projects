package com.wallet.dao;



public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(account_number2_sequence.NEXTVAL,?,?,?,?)";
	public static final String INSERT_QUERY1="INSERT INTO Acc_Detail VALUES(account_number2_sequence.CURRVAL,?,?)";
	public static final String EMPLOYEEID_QUERY_SEQUENCE="SELECT account_number2_sequence.CURRVAL FROM DUAL";
	public static final String INSERT_QUERY2="SELECT * FROM Acc_Detail WHERE account_number=?";
    public static final String UPDATE_QUERY_DEPOSIT="UPDATE Acc_Detail set account_balance=account_balance+? where account_number=?";
    public static final String UPDATE_QUERY_WITHDRAW="UPDATE Acc_Detail set account_balance=account_balance-? where account_number=?";
    public static final String UPDATE_QUERY_FUND_TRANFER_FROM="UPDATE Acc_Detail set account_balance=account_balance-? where account_number=?";
    public static final String UPDATE_QUERY_FUND_TRANSFER_TO="UPDATE Acc_Detail set account_balance=account_balance+? where account_number=?";
	//public static final String INSERT_QUERY5="SELECT * FROM Acc_Detail3 WHERE account_number=?";
    public static final String INSERT_QUERY_TRANSACTION="INSERT INTO Transaction VALUES(transaction_sequence1.NEXTVAL,?,?,?,?,?)";
    public static final String SELECT_QUERY="SELECT * from Transaction where t_account=? or sender_acc=? or recevier_acc=?";

}

/******************TABLESCRIPT*******************
CREATE TABLE EmployeeDetails(
employee_id NUMBER,
employee_name VARCHAR2(20)
);

CREATE SEQUENCE employeeId_sequence;

************************************************/