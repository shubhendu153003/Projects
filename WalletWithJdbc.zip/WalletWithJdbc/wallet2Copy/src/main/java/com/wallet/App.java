package com.wallet;

import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Date;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

public class App 
{
	WalletService ws = new WalletServiceImpl();
	Scanner input = new Scanner(System.in);
	
    public static void main( String[] args ) throws SQLException
    {
    
    	App A = new App();
       
    	while(true) {
    		System.out.println("=============XYZ BANK WALLET=================");
    		System.out.println("1. Create Account");
    		System.out.println("2. Show Account Balance");
    		System.out.println("3. Deposit");
    		System.out.println("4. Withdraw");
    		System.out.println("5. Fund Transfer");
    		System.out.println("6. Print Transaction");
    		System.out.println("7. Exit");
    		System.out.println("Enter option: ");
    		
    		String option = A.input.nextLine();
    		
    		
    		switch (option) {
			case "1": A.createAccount();
				break;
		case "2": A.showBalance();
				break;
			case "3": A.deposit();
				break;
			case "4": A.withdraw();
				break;
			case "5": A.fundTransfer();
				break;
			case "6": A.printTransaction();
				break;
			case "7":
				System.out.println("Thank You!");
				System.exit(0);
				break;
			default:
				System.out.println("Please select options from 1-7.");
				break;
			}
    	}  
    }
    
    public void createAccount(){
    	input.useDelimiter("/n");
    	Customer c = new Customer();
    	Account a = new Account();
    	
    	System.out.println("Enter name: ");
    	c.setName(input.nextLine());
    	
    	System.out.println("Enter Address: ");
    	c.setAddress(input.nextLine());
    	
    	System.out.println("Enter age: ");
    	c.setAge(input.nextLine());
    	
    	System.out.println("Enter phone number: ");
    	c.setPhone(input.nextLine());
    	
    	System.out.println("Enter account type: ");
    	a.setAccount_type(input.nextLine());
    	
    	System.out.println("Enter initial amount deposited: ");
    	a.setAccount_balance(Double.parseDouble(input.nextLine()));
    	
    	try {
		   boolean ok = ws.validateData(c,a);
		   if(ok == true) {
			   String acc = ws.createAccount(c,a);
			  if(acc != null) {
				  System.out.println("Account number " + acc + " created successfully.");
				  Date d=new Date();
				 double transId = ws.dwTransaction("success", "deposit", acc, a.getAccount_balance());
				  //System.out.println("Transaction Id: "+transId);*/
			  }
			  else {
				  System.out.println();
				  System.err.println("Some error in creating account.");
				  System.out.println();
			  }
		   }
		   else {
			   throw new WalletException("Error in the data provided.");
		   }
		} catch (WalletException e) {
				System.out.println();
				System.err.println("Error: "+e.getMessage());
				System.out.println();
		}
    	
    }
    
    public void showBalance() {
    	
    	System.out.println("Enter account number: ");
    	String acc = input.nextLine();
    	
    	try {
    		boolean b=ws.checkAccountExist(acc);
    		String bal = Double.toString(ws.showBalance(acc));
			if(bal != null) {
				System.out.println("Balance available for account number "+acc+ " is "+ bal);}
			//}
			else {
				System.out.println("Account number "+acc + " not found in database.");
			}
		} catch (WalletException e) {
			System.out.println();
			System.err.println("Error: "+e.getMessage());
			System.out.println();
		}
    }
   
    
    public void deposit() {
    	
    	System.out.println("Enter account number: ");
    	String acc = input.nextLine();
    	System.out.println("Enter amount to be deposited: ");
    	double amt = Double.parseDouble(input.nextLine());
    	
    	try {
    		boolean b=ws.checkAccountExist(acc);
    		/*if(!b)
    		{
    			throw new WalletException("AcountNumber Does Not Exist");
    		}*/
    		double totalAmt = ws.deposit(acc, amt);
			
				System.out.println("Amount "+amt+" deposited in account number "+ acc);
				
				double transId = ws.dwTransaction("success", "deposit", acc, amt);
			
		} catch (WalletException e) {
			System.out.println();
			System.err.println("Error: "+e.getMessage());
			System.out.println();
		}
    	
    }
    
    public void withdraw() {
    	System.out.println("Enter account number: ");
    	String acc = input.nextLine();
    	System.out.println("Enter amount to be withdrawn: ");
    	double amt = Double.parseDouble(input.nextLine());
    	
    	try {
    		boolean b=ws.checkAccountExist(acc);
    	/*	if(!b)
    		{
    			throw new WalletException("AcountNumber Does Not Exist");
    		}*/
    		double totalAmt = ws.withdraw(acc, amt);
			
      		System.out.println("Amount "+amt+" withdrawn from account number "+ acc);
			System.out.println("New balance "+totalAmt);
				
				double transId = ws.dwTransaction("success", "whitdrawal", acc, amt);
			
		} catch (WalletException e) {
			System.out.println();
			System.err.println("Error: "+e.getMessage());
			System.out.println();
		}
    }
    
    public void fundTransfer() {
    	System.out.println("Enter your account number: ");
    	String acc = input.nextLine();
    	
    	System.out.println("Enter amount to be transferred: ");
    	double amt = Double.parseDouble(input.nextLine());
    	
    	System.out.println("Enter receivers account number: ");
    	String rAcc = input.nextLine();
    	
    	try {
    		boolean b=ws.checkAccountExist(acc);
    		boolean b1=ws.checkAccountExist(rAcc);
    		/*if(!(b&&b1))
    		{
    			throw new WalletException("AcountNumber Does Not Exist");
    		}*/
			 double balance = ws.fundTransfer(acc, amt, rAcc);
			
				 System.out.println("Amount "+ amt + " transferred to account number "+rAcc +" successfully");
				 
				 double transId = ws.transferTransaction("success", "transfer", acc, rAcc, amt);
			 
		} catch (WalletException e) {
			System.out.println();
			System.err.println(e.getMessage());
			System.out.println();
		}
    }
    
    public void printTransaction() throws SQLException {
    	System.out.println("Enter account number: ");
    	String acc = input.nextLine();
    	
    	try {
			  boolean check = ws.checkAccountExist(acc);
			
				  System.out.println("Transaction History\n======================================"); 
				  
				   ResultSet s=ws.printTransaction(acc);
				   boolean m=s.next();
				   if(m)
				   {
					 while(m)
					 {
				      System.out.println("Transaction ID         : "+ s.getString(1));
					  System.out.println("Type                   : "+ s.getString(2));
					  System.out.println("Amount                 : "+ s.getDouble(4));
					 if(s.getString(2).equals("transfer")) {
					  System.out.println("Sender Account number  : "+ s.getString(5));
					  System.out.println("Receiver Account number: "+ s.getString(6));
                     m=s.next(); 
                     System.out.println("=====================================");
					 }				   
					 else {
					  System.out.println("Account number         : "+ s.getString(3));
	                     m=s.next(); 
                       System.out.println("=====================================");
					 }
					 System.out.println();
					 }
				   }
				   else
				   {
					   System.out.println("No Record Found");

				   }
				  }
			  

		 catch (WalletException e) {
			System.err.println(e.getMessage());
		}
    }
    
    
  
}
