package com.wallet.bean;

import java.util.HashMap;

public class Account {

	private String account_type;
	private String account_balance;
	
	
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(String account_balance) {
		this.account_balance = account_balance;
	}
	
	
	
	public Account(String account_type, String account_balance) {
		super();
		this.account_type = account_type;
		this.account_balance = account_balance;
	}

	public Account() {
		super();
	}
	
	
	private static HashMap<String,Customer> account_customer_map = new HashMap<String,Customer>();
	
	private static HashMap<String, Account> account_details_map = new HashMap<String,Account>();
	
	static {
		account_customer_map.put("SCB1531121607164", new Customer("Mark", "MIPL chengalpattu", "25", "9857465241"));
		account_customer_map.put("SCB1531121607170", new Customer("Ashish", "Velachery Chennai", "35", "8542465241"));
		account_customer_map.put("SCB1531121607172", new Customer("Ankit", "ICF Road Tambaram", "22", "9852415241"));
		account_customer_map.put("SCB1531121607173", new Customer("Vikas", "Avadi Chennai", "29", "9885462141"));
		account_customer_map.put("SCB1531121607180", new Customer("Vicky", "SIPCOT Siruseri", "31", "8452136541"));
		account_customer_map.put("SCB1531121607185", new Customer("Aditya", "Bangalore", "26", "8585745241"));
		account_customer_map.put("SCB1531121607189", new Customer("Manish", "Kanchipuram", "30", "7584625241"));
		account_customer_map.put("SCB1531121607190", new Customer("Akash", "PCT Karapakkam", "25", "8585865241"));
		account_customer_map.put("SCB1531121607192", new Customer("Kunal", "Thiruvanmiyur", "28", "8585765241"));
		account_customer_map.put("SCB1531121607195", new Customer("Mahesh", "Coimbatore", "35", "9857865412"));
		
	}
	
	static {
		
		account_details_map.put("SCB1531121607164", new Account("Saving", "85000"));
		account_details_map.put("SCB1531121607170", new Account("Current", "8000"));
		account_details_map.put("SCB1531121607172", new Account("Saving", "74000"));
		account_details_map.put("SCB1531121607173", new Account("Current", "5000"));
		account_details_map.put("SCB1531121607180", new Account("Current", "200000"));
		account_details_map.put("SCB1531121607185", new Account("Current", "56000"));
		account_details_map.put("SCB1531121607189", new Account("Saving", "850000"));
		account_details_map.put("SCB1531121607190", new Account("Saving", "44000"));
		account_details_map.put("SCB1531121607192", new Account("Saving", "45000"));
		account_details_map.put("SCB1531121607195", new Account("Saving", "97000"));
	}
	
	public static HashMap<String, Customer> getAccCustMap() {
		return account_customer_map;
	}
	public static HashMap<String, Account> getAccDetailMap() {
		return account_details_map;
	}
	
}
